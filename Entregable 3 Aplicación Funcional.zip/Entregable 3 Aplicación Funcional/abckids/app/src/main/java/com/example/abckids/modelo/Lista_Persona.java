package com.example.abckids.modelo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.abckids.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Lista_Persona extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_persona);
        final Base based=new Base(getApplicationContext());

        //cast listview
        final Cursor cursorPersona=based.listar();
        String[] desde= new String []{"per_id","nombre","apellido","correo"};
        int [] hasta=new int[]{R.id.txtCodigo,R.id.txtNombre,R.id.txtApellido,R.id.txtCorreo};

        final CursorAdapter ProductoAdapter=new SimpleCursorAdapter(getApplicationContext(),
                R.layout.lista_persona,cursorPersona,desde,hasta,0);
        final ListView listView=(ListView)findViewById(R.id.listPersonas);
        listView.setAdapter(ProductoAdapter);
        //vincular el boton
        FloatingActionButton faNuevoProducto=(FloatingActionButton) findViewById(R.id.btnagregar_persona);
        faNuevoProducto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent (getApplicationContext(), registrarse.class);
                startActivity(intent);

            }
        });
        //eliminar--------------------------------------
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Cursor persona=(Cursor)listView.getItemAtPosition(position);
                String cod=persona.getString(1);
                String mensaje=based.ElimnarPersona(cod);
                if(mensaje==null){
                    Toast.makeText(getApplicationContext(),"Producto Eliminado",Toast.LENGTH_LONG).show();
                    //Recargar la lista de productos
                    ProductoAdapter.swapCursor(based.listar());
                    listView.setAdapter(ProductoAdapter);
                }else{
                    Toast.makeText(getApplicationContext(),mensaje,Toast.LENGTH_LONG).show();

                }
                Toast.makeText(getApplicationContext(),"ELIMINAR"+cod,Toast.LENGTH_LONG).show();
                return false;
            }
        });



    }
}

