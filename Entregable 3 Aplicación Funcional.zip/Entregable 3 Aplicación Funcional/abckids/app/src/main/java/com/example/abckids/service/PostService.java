package com.example.abckids.service;

import com.example.abckids.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface PostService {
    String url="/users";
    @GET(url)
    Call<List<Post>> getPost();
}
// h