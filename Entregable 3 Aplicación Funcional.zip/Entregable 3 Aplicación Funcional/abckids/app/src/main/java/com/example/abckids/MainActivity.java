package com.example.abckids;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.abckids.modelo.Base;
import com.example.abckids.modelo.Consumo;
import com.example.abckids.modelo.Lista_Persona;
import com.example.abckids.modelo.registrarse;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void registrarse(View view) {
        Intent intent2 = new Intent(this, registrarse.class);
        startActivity(intent2);

    }



    public void Listar(View view){
        Intent intent = new Intent(this, Lista_Persona.class);
        startActivity(intent);
    }

    public void menu_principal(View view) {
        final Base db = new Base(getApplicationContext());
        final TextView correo = (TextView)findViewById(R.id.editTextTextEmailAddress);
        final TextView pass = (TextView)findViewById(R.id.editTextTextPassword);
        final Cursor data = db.iniciar(correo.getText().toString(),pass.getText().toString());
        if (data == null){
            Toast.makeText(getApplicationContext(),"Datos incorrectos",Toast.LENGTH_SHORT).show();
        }else{
            Intent intent = new Intent(this, menu_principal.class);
            startActivity(intent);
        }
    }


}