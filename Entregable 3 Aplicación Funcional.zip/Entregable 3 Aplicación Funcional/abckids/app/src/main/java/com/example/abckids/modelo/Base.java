package com.example.abckids.modelo;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Base extends SQLiteOpenHelper {
    private static final String DATABASE="data.db";
    Context micontext;
    public Base(@Nullable Context context){
        super(context,DATABASE,null,1);
        micontext=context;
        File archivo = micontext.getDatabasePath(DATABASE);
        if (verificaBD(archivo.getAbsolutePath())){
            try {
                copiarBD(archivo);
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }
    private boolean verificaBD(String ruta){
        SQLiteDatabase mibase=null;
        try{
            mibase=SQLiteDatabase.openDatabase(ruta,null,SQLiteDatabase.OPEN_READONLY);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        if (mibase!=null){
            mibase.close();
        }
        return mibase!=null;
    }
    private void copiarBD(File archivoBD) throws IOException {
        InputStream inputStream = micontext.getAssets().open(DATABASE);
        OutputStream outputStream = new FileOutputStream(archivoBD);
        byte[] buffer = new byte [1024];
        int largo;
        while ((largo=inputStream.read(buffer))>0){
            outputStream.write(buffer,0,largo);
        }
        outputStream.flush();
        outputStream.close();
        inputStream.close();
    }

    //Listar
    public Cursor listar(){
        Cursor cursor;
        String sql = "SELECT ROWID as _id, * FROM persona";
        cursor = this.getReadableDatabase().rawQuery(sql,null);
        return cursor;
    }

    //Iniciar Sesión
    public Cursor iniciar(String correo, String contraseña){
        String sql = "SELECT ROWID as _id, * FROM persona WHERE correo = '"+correo+"' AND contraseña = '"+contraseña+"'";
        Cursor cursor;
        try {
            cursor = this.getReadableDatabase().rawQuery(sql, null);
        }catch (SQLException e){
            System.out.println(e.getMessage());
            return null;
        }
        return cursor;
    }

    //Registrar
    public String nuevo(Persona p){
        String sql = "INSERT INTO persona VALUES('"+p.getId()+"','"
                +p.getNombre()+"','"
                +p.getApellido()+"','"
                +p.getCorreo()+"','"
                +p.getContraseña()+"')";
        try {
            this.getWritableDatabase().execSQL(sql);
            return "Creado";
        }catch (SQLException e){
            return e.getMessage();
        }
    }

    //Eliminar persona de la base de datos
    public String ElimnarPersona(String id){
        String sql="DELETE FROM persona WHERE per_id IN ('"+id+"');";
        try {
            this.getWritableDatabase().execSQL(sql);
        }catch(SQLException ex){
            return "Error en la eliminacion del persona "+ex.getMessage();
        }
        return null;
    }
    public String EditarProducto(Persona p){
        String sql = "UPDATE productos SET " +
                "per_id = '"+p.getId()+"', " +
                "nombre = '"+p.getNombre()+"', " +
                "apellido = '"+p.getApellido()+"', " +
                "correo = '"+p.getCorreo()+"', " +
                "contraseña = '"+p.getContraseña()+"', " +
                "WHERE codigo= '"+p.getId()+"'";
        try {
            this.getWritableDatabase().execSQL(sql);
        }catch (SQLException e){
            return "Error en la modificación del producto: "+ e.getMessage();
        }
        return null;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
