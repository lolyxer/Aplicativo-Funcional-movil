package com.example.abckids.modelo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.abckids.MainActivity;
import com.example.abckids.R;
import com.example.abckids.modelo.Base;
import com.example.abckids.modelo.Persona;

public class registrarse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarse);
    }


    public void volver_inicio(View view) {
        final Persona p = new Persona();
        final Base db = new Base(getApplicationContext());
        final TextView nombre = (TextView)findViewById(R.id.editTextTextPersonName);
        final TextView correo = (TextView)findViewById(R.id.editTextTextEmailAddress2);
        final TextView apellido = (TextView)findViewById(R.id.editTextTextPersonName2);
        final TextView contraseña = (TextView)findViewById(R.id.editTextTextPassword2);
        final TextView rapcontra = (TextView)findViewById(R.id.editTextTextPassword3);
        if (contraseña.getText().toString().equals(rapcontra.getText().toString())){
            p.setId("Prueba01");
            p.setNombre(nombre.getText().toString());
            p.setApellido(apellido.getText().toString());
            p.setCorreo(correo.getText().toString());
            p.setContraseña(contraseña.getText().toString());
            Toast.makeText(getApplicationContext(),db.nuevo(p),Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }else{
            Toast.makeText(getApplicationContext(),"Error Fatal",Toast.LENGTH_SHORT).show();
        }

    }


}